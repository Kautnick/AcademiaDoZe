IF DB_ID(N'db_academia_do_ze') IS NULL
BEGIN
    CREATE DATABASE db_academia_do_ze;
END
GO
USE db_academia_do_ze;
GO
IF OBJECT_ID(N'dbo.tb_logradouro', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.tb_logradouro (
        id_logradouro INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_tb_logradouro PRIMARY KEY,
        cep VARCHAR(8) NOT NULL CONSTRAINT UQ_tb_logradouro_cep UNIQUE,
        nome VARCHAR(150) NOT NULL,
        bairro VARCHAR(100) NOT NULL,
        cidade VARCHAR(100) NOT NULL,
        estado CHAR(2) NOT NULL,
        pais VARCHAR(50) NOT NULL CONSTRAINT DF_tb_logradouro_pais DEFAULT 'Brasil'
    );
    CREATE INDEX IX_tb_logradouro_cep ON dbo.tb_logradouro(cep);
    CREATE INDEX IX_tb_logradouro_cidade ON dbo.tb_logradouro(cidade);
END
GO

IF OBJECT_ID(N'dbo.tb_aluno', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.tb_aluno (
        id_aluno INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_tb_aluno PRIMARY KEY,
        cpf VARCHAR(11) NOT NULL CONSTRAINT UQ_tb_aluno_cpf UNIQUE,
        nome VARCHAR(150) NOT NULL,
        nascimento DATE NOT NULL,
        telefone VARCHAR(15) NOT NULL,
        email VARCHAR(150) NOT NULL,
        logradouro_id INT NOT NULL,
        numero VARCHAR(20) NOT NULL,
        complemento VARCHAR(100) NULL,
        senha VARCHAR(255) NOT NULL,
        foto VARBINARY(MAX) NULL,
        CONSTRAINT FK_tb_aluno_tb_logradouro FOREIGN KEY(logradouro_id) REFERENCES dbo.tb_logradouro(id_logradouro)
    );
    CREATE INDEX IX_tb_aluno_cpf ON dbo.tb_aluno(cpf);
END
GO

IF OBJECT_ID(N'dbo.tb_colaborador', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.tb_colaborador (
        id_colaborador INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_tb_colaborador PRIMARY KEY,
        cpf VARCHAR(11) NOT NULL CONSTRAINT UQ_tb_colaborador_cpf UNIQUE,
        nome VARCHAR(150) NOT NULL,
        nascimento DATE NOT NULL,
        telefone VARCHAR(15) NOT NULL,
        email VARCHAR(150) NOT NULL,
        logradouro_id INT NOT NULL,
        numero VARCHAR(20) NOT NULL,
        complemento VARCHAR(100) NULL,
        senha VARCHAR(255) NOT NULL,
        foto VARBINARY(MAX) NULL,
        admissao DATE NOT NULL,
        tipo INT NOT NULL,
        vinculo INT NOT NULL,
        CONSTRAINT FK_tb_colaborador_tb_logradouro FOREIGN KEY(logradouro_id) REFERENCES dbo.tb_logradouro(id_logradouro)
    );
    CREATE INDEX IX_tb_colaborador_cpf ON dbo.tb_colaborador(cpf);
END
GO

IF OBJECT_ID(N'dbo.tb_matricula', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.tb_matricula (
        id_matricula INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_tb_matricula PRIMARY KEY,
        aluno_id INT NOT NULL,
        plano INT NOT NULL,
        data_inicio DATE NOT NULL,
        data_fim DATE NOT NULL,
        objetivo VARCHAR(500) NOT NULL,
        restricao_medica INT NOT NULL CONSTRAINT DF_tb_matricula_restricao DEFAULT 0,
        obs_restricao VARCHAR(500) NULL,
        laudo_medico VARBINARY(MAX) NULL,
        CONSTRAINT FK_tb_matricula_tb_aluno FOREIGN KEY(aluno_id) REFERENCES dbo.tb_aluno(id_aluno) ON DELETE CASCADE
    );
    CREATE INDEX IX_tb_matricula_aluno_id ON dbo.tb_matricula(aluno_id);
    CREATE INDEX IX_tb_matricula_data_fim ON dbo.tb_matricula(data_fim);
END
GO

IF OBJECT_ID(N'dbo.tb_acesso', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.tb_acesso (
        id_acesso INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_tb_acesso PRIMARY KEY,
        pessoa_tipo INT NOT NULL,
        pessoa_id INT NOT NULL,
        data_hora DATETIME NOT NULL CONSTRAINT DF_tb_acesso_data_hora DEFAULT GETDATE()
    );
    CREATE INDEX IX_tb_acesso_pessoa ON dbo.tb_acesso(pessoa_tipo, pessoa_id);
    CREATE INDEX IX_tb_acesso_data_hora ON dbo.tb_acesso(data_hora);
END

GO
